# DailyBook
小程序的开发工作


1.login

	其内文件为分离出来的login函数
	可根据业务需求进行样式修改及调整，切记只有button能够吊起用户授权

2.app.js

	其内文件均为登陆及其他函数运行时封装的方法
	其中loginFntemplate 为授权后无记录是运行的方法
	
	getUserInfo为未授权时引用的方法
	
	
	
	
	
	
	Email: Senmeiset@gmail.com
